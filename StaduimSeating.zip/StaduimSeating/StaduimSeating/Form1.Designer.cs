﻿namespace StaduimSeating
{
    partial class frmStadiumSeating
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtTicketClassA = new System.Windows.Forms.TextBox();
            this.txtTicketClassB = new System.Windows.Forms.TextBox();
            this.txtTicketClassC = new System.Windows.Forms.TextBox();
            this.btnCalculateRevenue = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.txtTotalClassA = new System.Windows.Forms.TextBox();
            this.txtTotalClassB = new System.Windows.Forms.TextBox();
            this.txtTotalClassC = new System.Windows.Forms.TextBox();
            this.txtGrandTotal = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtTicketClassA
            // 
            this.txtTicketClassA.Location = new System.Drawing.Point(103, 88);
            this.txtTicketClassA.Name = "txtTicketClassA";
            this.txtTicketClassA.Size = new System.Drawing.Size(126, 22);
            this.txtTicketClassA.TabIndex = 0;
            // 
            // txtTicketClassB
            // 
            this.txtTicketClassB.Location = new System.Drawing.Point(103, 116);
            this.txtTicketClassB.Name = "txtTicketClassB";
            this.txtTicketClassB.Size = new System.Drawing.Size(126, 22);
            this.txtTicketClassB.TabIndex = 1;
            // 
            // txtTicketClassC
            // 
            this.txtTicketClassC.Location = new System.Drawing.Point(103, 144);
            this.txtTicketClassC.Name = "txtTicketClassC";
            this.txtTicketClassC.Size = new System.Drawing.Size(126, 22);
            this.txtTicketClassC.TabIndex = 2;
            // 
            // btnCalculateRevenue
            // 
            this.btnCalculateRevenue.Location = new System.Drawing.Point(134, 259);
            this.btnCalculateRevenue.Name = "btnCalculateRevenue";
            this.btnCalculateRevenue.Size = new System.Drawing.Size(96, 53);
            this.btnCalculateRevenue.TabIndex = 3;
            this.btnCalculateRevenue.Text = "&Calculate Revenue";
            this.btnCalculateRevenue.UseVisualStyleBackColor = true;
            this.btnCalculateRevenue.Click += new System.EventHandler(this.btnCalculateRevenue_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(248, 259);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(96, 53);
            this.btnClear.TabIndex = 4;
            this.btnClear.Text = "Cl&ear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Location = new System.Drawing.Point(359, 259);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(96, 53);
            this.btnExit.TabIndex = 5;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // txtTotalClassA
            // 
            this.txtTotalClassA.Enabled = false;
            this.txtTotalClassA.Location = new System.Drawing.Point(109, 31);
            this.txtTotalClassA.Name = "txtTotalClassA";
            this.txtTotalClassA.Size = new System.Drawing.Size(126, 22);
            this.txtTotalClassA.TabIndex = 6;
            this.txtTotalClassA.TabStop = false;
            this.txtTotalClassA.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtTotalClassB
            // 
            this.txtTotalClassB.Enabled = false;
            this.txtTotalClassB.Location = new System.Drawing.Point(109, 59);
            this.txtTotalClassB.Name = "txtTotalClassB";
            this.txtTotalClassB.Size = new System.Drawing.Size(126, 22);
            this.txtTotalClassB.TabIndex = 7;
            this.txtTotalClassB.TabStop = false;
            this.txtTotalClassB.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtTotalClassC
            // 
            this.txtTotalClassC.Enabled = false;
            this.txtTotalClassC.Location = new System.Drawing.Point(109, 87);
            this.txtTotalClassC.Name = "txtTotalClassC";
            this.txtTotalClassC.Size = new System.Drawing.Size(126, 22);
            this.txtTotalClassC.TabIndex = 8;
            this.txtTotalClassC.TabStop = false;
            this.txtTotalClassC.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtGrandTotal
            // 
            this.txtGrandTotal.Enabled = false;
            this.txtGrandTotal.Location = new System.Drawing.Point(109, 127);
            this.txtGrandTotal.Name = "txtGrandTotal";
            this.txtGrandTotal.Size = new System.Drawing.Size(126, 22);
            this.txtGrandTotal.TabIndex = 9;
            this.txtGrandTotal.TabStop = false;
            this.txtGrandTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtTicketClassC);
            this.groupBox1.Controls.Add(this.txtTicketClassB);
            this.groupBox1.Controls.Add(this.txtTicketClassA);
            this.groupBox1.Location = new System.Drawing.Point(25, 21);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(278, 214);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tickets Sold";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(21, 28);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(208, 34);
            this.label8.TabIndex = 6;
            this.label8.Text = "Enter the number of tickets sold\r\nfor each class of seats.";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(29, 144);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 17);
            this.label3.TabIndex = 5;
            this.label3.Text = "Class C:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 116);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "Class B:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 88);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "Class A:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.txtGrandTotal);
            this.groupBox2.Controls.Add(this.txtTotalClassC);
            this.groupBox2.Controls.Add(this.txtTotalClassB);
            this.groupBox2.Controls.Add(this.txtTotalClassA);
            this.groupBox2.Location = new System.Drawing.Point(320, 75);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(253, 160);
            this.groupBox2.TabIndex = 14;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Revenue Generated";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(50, 130);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 17);
            this.label7.TabIndex = 13;
            this.label7.Text = "Total:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(35, 90);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 17);
            this.label6.TabIndex = 12;
            this.label6.Text = "Class C:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(35, 62);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 17);
            this.label5.TabIndex = 11;
            this.label5.Text = "Class B:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(35, 34);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 17);
            this.label4.TabIndex = 10;
            this.label4.Text = "Class A:";
            // 
            // frmStadiumSeating
            // 
            this.AcceptButton = this.btnCalculateRevenue;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(602, 339);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnCalculateRevenue);
            this.Name = "frmStadiumSeating";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Stadium Seating";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtTicketClassA;
        private System.Windows.Forms.TextBox txtTicketClassB;
        private System.Windows.Forms.TextBox txtTicketClassC;
        private System.Windows.Forms.Button btnCalculateRevenue;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.TextBox txtTotalClassA;
        private System.Windows.Forms.TextBox txtTotalClassB;
        private System.Windows.Forms.TextBox txtTotalClassC;
        private System.Windows.Forms.TextBox txtGrandTotal;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label8;
    }
}

