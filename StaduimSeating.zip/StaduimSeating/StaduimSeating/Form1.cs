﻿/*
 * Date: 18-SEP-2020
 * Programmer: Dan Hopp
 * Funciton: A form used to calculate seating sales at an athletic stadium. There are three
 * categories. Class A @ $15 each, Class B @ $12 each, and Class C @ $9 each.
 * 
 * Data validation is used to verify input, with an overflow and generic Exception catch in
 * place as backup.
 * 
 * Non-integers or integers greater than 100000 or less than 0 are not allowed. All the input fields 
 * cannot be blank. At calculation, if at least one input field has data in it, populate the other 
 * blank input fields with a 0.
 * 
 * Display the results in currency format.
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StaduimSeating
{
    public partial class frmStadiumSeating : Form
    {
        public frmStadiumSeating()
        {
            InitializeComponent();
        }

        //Close form
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //Clear all text fields
        private void btnClear_Click(object sender, EventArgs e)
        {
            /*
             * How-to-loop-through-text-boxes borrowed from
             * https://stackoverflow.com/questions/28622186/c-sharp-looping-through-textboxes-in-a-groupbox
             * and tweaked to account for the text boxes residing in Group Boxes
             */

            //Loop through group boxes
            foreach (Control groupBoxCtrl in this.Controls)
            {
                GroupBox groupBox = groupBoxCtrl as GroupBox;

                if (groupBox != null)
                {
                    //loop through text boxes
                    foreach (Control txtBoxCtrl in groupBox.Controls)
                    {

                        TextBox textBox = txtBoxCtrl as TextBox;

                        if (textBox != null)
                        {
                            textBox.Text = "";
                        }

                    }
                }
            }
        }

        //Set cost values
        enum Seating {
            ClassA = 15,
            ClassB = 12,
            ClassC = 9
        }

        private void btnCalculateRevenue_Click(object sender, EventArgs e)
        {
            //Is data valid?
            if (IsDataValid())
            {
                //Calculate revenue
                try
                {
                    //Class A totals
                    int classAtotal = (int.Parse(txtTicketClassA.Text) * (int)Seating.ClassA);
                    txtTotalClassA.Text = classAtotal.ToString("c");

                    //Class B totals
                    int classBtotal = (int.Parse(txtTicketClassB.Text) * (int)Seating.ClassB);
                    txtTotalClassB.Text = classBtotal.ToString("c");

                    //Class C totals
                    int classCtotal = (int.Parse(txtTicketClassC.Text) * (int)Seating.ClassC);
                    txtTotalClassC.Text = classCtotal.ToString("c");

                    //Grand total
                    txtGrandTotal.Text = (classAtotal + classBtotal + classCtotal).ToString("c");

                }
                //For any variable overflows
                catch (OverflowException oe)
                {
                    DisplayMessage("Number is out of range. The stadium cannot seat that meany.",
                        "Ye Cannae Change the Laws of Physics", txtTicketClassA);
                }
                //Catch all other unexpecteds
                catch (Exception ex)
                {
                    DisplayMessage(ex.Message +
                        "\n" + ex.StackTrace, "An Exception Has Occured", txtTicketClassA);
                }
            }
        }

        //Data vaildation. Use a foreach to loop through the text fields in the Tickets Sold 
        //group box
        private Boolean IsDataValid()
        {
            Boolean IsValid = true;

            //Are all the ticket fields blank?
            //Concantenate tickets into one string
            String tickets = txtTicketClassA.Text + txtTicketClassB.Text +
                txtTicketClassC.Text;

            //If blank, display message and set focus to Class A tickets
            if (tickets == "")
            {
                DisplayMessage("Please enter an integer in at least one of the "
                    + "seat classes.", "No Ticket", txtTicketClassA);
                return false;
            }

            //Loop through text boxes in Tickets Sold group box
            foreach (Control txtBoxCtrl in groupBox1.Controls)
            {
            TextBox textBox = txtBoxCtrl as TextBox;
                if (textBox != null)
                {
                    //Check for fields with no text
                    if (textBox.Text == "")
                    {
                        //If one field has text but the others are blank, 
                        //populate the blank fields with a 0
                        PopulateBlankWithZero(textBox);
                    }

                    //check only the fields with text in them
                    if (textBox.Text != "")
                    {
                        //If any data validation logic returns false, exit the foreach

                        //Are the text boxes integer only?
                        if (!(IsValid = IsNumberAnInteger(textBox)))
                        {
                            return IsValid;
                        }

                        //Is the integer greater than -1 and less than 100,001?
                        if (!(IsValid = IsIntegerWithinRange(textBox)))
                        {
                            return IsValid;
                        }
                    }
                }
            }
            return IsValid;
        }

        //Populate the blank Tickets Sold text fields with a 0
        private void PopulateBlankWithZero(TextBox textBox)
        {

            //check only the fields that are blank
            if (textBox.Text == "")
            {
                textBox.Text = "0";
            }

        }

        //Are the text boxes integer only?
        private Boolean IsNumberAnInteger(TextBox textBox) {

            Int32 temp;  //Make TryParse happy
            Boolean isInteger = true;

            //Is an integer?
            isInteger = Int32.TryParse(textBox.Text, out temp);
            //If not, display message and set focus on the invalid field
            if (!isInteger)
            {
                DisplayMessage("'" + textBox.Text + "' is not a valid number. "
                    + "Please enter an integer greater than 0 or less than 100000 in the text field.",
                    "Invalid Number", textBox);
                return isInteger;
            }
            return isInteger;
        }

        //Are the integers within range?
        private Boolean IsIntegerWithinRange(TextBox textBox)
        {
            Int32 tempInt;  //Make Parse happy
            Boolean isRangeValid = true;

            //Is the integer greater than -1 and less than 100,001?
            tempInt = Int32.Parse(textBox.Text);
            //If not, display message and set focus on the invalid field
            if (tempInt < 0 || tempInt > 100000)
            {
                isRangeValid = false;
                DisplayMessage("'" + textBox.Text + "' is invalid. The integer cannot " +
                    "be less than zero or greater than 100000.", "Number is Out of Range", textBox);
                return isRangeValid;
            }
            return isRangeValid;
        }

        //Function to display a message and set focus to the text field
        private void DisplayMessage(string message, string title, TextBox textBox)
        {
            MessageBox.Show(message, title);
            textBox.Focus();
        }
    }
}
