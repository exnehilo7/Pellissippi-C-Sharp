﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    //Make static so an instance of the class does not have to be created??
    class Calculator
    {
        //-----------Variables--------------
        public bool basicOperationClicked = false;
        public bool beginNewNumber = true;
        public enum Operator : short
        {
            Add = 1,
            Subtract = 2,
            Multiply = 3,
            Divide = 4,
            SquareRoot = 5,
            Reciprocal = 6,
            None = 0
        }

        //------Constructors------



        //------Properties-------
        public short op { get;  set; }  //Stores a member of the Operator enumeration
        public decimal operand1 { get; set; }  //the left # in the equation
        public decimal operand2 { get; set; }  //the right # in the equation
        public decimal currentValue { get; set; } //the result
        public decimal repeatedOperationVal { get; set; }  //placeholder for click-equals-to-repeat


        #region Methods

        //Perform an operation using just operand 1
        public void SingleOperandOperation(string number, short operation)
        {

            operand1 = Convert.ToDecimal(number);
            currentValue = operand1;
            //Perform operation
            PerformOperation(operation);


        }

        //Perform an operation using both operands 1 and 2
        public void DoubleOperandOperation(string number)
        {

            if (basicOperationClicked)
            {
                operand2 = Convert.ToDecimal(number);
            }
            //Call method to do the maths
            PerformOperation(op);

        }

        //Store the txtbox value into operand 1, the currentValue, and the 
        //button's operation to be performed
        public void StoreSingleOperand(string number, short operation)
        {

            operand1 = Convert.ToDecimal(number);
            op = operation;
        }

        //Do the maths
        private void PerformOperation(short operation)
        {
            switch (operation)
            {
                case (short)Operator.SquareRoot:
                    operand1 = (decimal)Math.Sqrt((double)operand1);
                    currentValue = operand1;
                    break;
                case (short)Operator.Reciprocal:
                    operand1 = 1 / operand1;
                    currentValue = operand1;
                    break;
                case (short)Operator.Add:
                    //Repeat previous operation
                    if (!basicOperationClicked)
                    {
                        currentValue = repeatedOperationVal + operand2;
                        repeatedOperationVal = currentValue;
                    }
                    //First-time operation
                    else
                    {
                        repeatedOperationVal = operand1 + operand2;
                        currentValue = operand1 + operand2;
                    }
                    break;
                case (short)Operator.Subtract:
                    //Repeat previous operation
                    if (!basicOperationClicked)
                    {
                        currentValue = repeatedOperationVal - operand2;
                        repeatedOperationVal = currentValue;
                    }
                    //First-time operation
                    else
                    {
                        repeatedOperationVal = operand1 - operand2;
                        currentValue = operand1 - operand2;
                    }
                    break;
                case (short)Operator.Multiply:
                    //Repeat previous operation
                    if (!basicOperationClicked)
                    {
                        currentValue = repeatedOperationVal * operand2;
                        repeatedOperationVal = currentValue;
                    }
                    //First-time operation
                    else
                    {
                        repeatedOperationVal = operand1 * operand2;
                        currentValue = operand1 * operand2;
                    }
                    break;
                case (short)Operator.Divide:
                    //Repeat previous operation
                    if (!basicOperationClicked)
                    {
                        currentValue = repeatedOperationVal / operand2;
                        repeatedOperationVal = currentValue;
                    }
                    //First-time operation
                    else
                    {
                        repeatedOperationVal = operand1 / operand2;
                        currentValue = operand1 / operand2;
                    }
                    break;
            }
        }
        #endregion
    }
}
