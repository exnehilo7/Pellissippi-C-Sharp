﻿/* Date: 21-OCT-2020
 * Programmer: Dan Hopp
 * Description: 
 * 
•	To perform an addition, subtraction, multiplication, or division operation, the user clicks the 
first number, followed by the appropriate operator key (+, -, *, /), followed by the second number and 
the equals key (=).

•	To perform an addition, subtraction, multiplication, or division operation on the result of a previous
operation, the user clicks another operator key, followed by another number and the equals key. The user 
can also repeat the previous operation on the result by clicking the equals keys without first clicking 
another operator and number.

•	To calculate the square root or the reciprocal of a number or to change the sign of a number, the user
clicks the number followed by the appropriate operator key (sqrt, 1/X, +/-).

•	To calculate the square root or the reciprocal of the result of a previous operation, the user clicks 
the appropriate operator key.

•	Each time the user clicks a number key, the number is displayed in the text box at the top of the form.
This text box also displays the result of an operation when the user clicks the sqrt, 1/X, +/-, or = key.

•	To erase the last digit entered, the user clicks the Back key.

•	To clear all the values entered, the user clicks the Clear key.

•	There is a class named Calculator that implements the functions of the calculator. 

•	The Calculator class accepst decimal parameters and provides a decimal result for its calculated values.

•	If the user tries to divide a number by zero or calculate the square root of a negative number, the 
calculator will display an error message in the text box. The errors are caught via try-catch statements.


Note: the user has to click the = or the special computation buttons to perform a calcualtion. Pressing
    #1 + #2 + #3 =  will result in the last two numbers used, ie #2 + #3; not #1 + #2 + #3

 * 
 * 
 */



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{


    public partial class frmCalculator : Form
    {
        //Calculator object variable
        Calculator calc = new Calculator();

        private bool beginNewNumber = false;  //Begin a new number in the text field?

        public frmCalculator()
        {
            InitializeComponent();
        }

        //Form load. Set form and class variables
        private void Form1_Load(object sender, EventArgs e)
        {
            //Start calculator at zero
            ResetCalculator();

        }

        //Method to display the result in the text box
        private void DisplayResult()
        {
            txtValue.Text = calc.currentValue.ToString();
        }

        //Method to reset the calculator
        private void ResetCalculator()
        {
            calc.op = 0;
            calc.operand1 = 0;
            calc.operand2 = 0;
            calc.currentValue = 0;
            beginNewNumber = false;
            txtValue.Text = "0";
        }

        //Validate that number is decimal
        private bool IsDecimal(string number)
        {
            if (Decimal.TryParse(number, out decimal decDigit))
            {
                return true;
            }

            //If NaN, set operands and current value to 0
            ResetCalculator();
            MessageBox.Show(number + " is not a valid number!");
            return false;
        }


        #region Add and Remove characters from textbox
        //Add a character from one of the character buttons to the end of the textbox value
        private void AddDigitToValue(string digit)
        {

            //If the value needs to be a new number, set the string to "0"
            if (beginNewNumber)
            {
                txtValue.Text = "0";
                beginNewNumber = false;
            }

            string tempValue = txtValue.Text;

            tempValue = tempValue + digit;

            //Add digit to the end & Display the new value
            //If starting number is 0 and decimal was pressed, don't remove the leading 0
            if (tempValue.IndexOf(".") == -1){
                /*Adjust if the number begins with a zero
                    TrimStart method learned from 
                https://www.tutorialspoint.com/Remove-Leading-Zeros-from-a-String-in-Chash
                */
                tempValue = tempValue.TrimStart(new Char[] { '0' });
            }

            //If value was all 0's, set to zero
            if (tempValue.Length == 0)
            {
                tempValue = "0";
            }

            //Display value
            txtValue.Text = tempValue;

        }

        //Remove a decimal character from the end of the textbox value
        private void RemoveDigitFromValue()
        {
            string tempValue = txtValue.Text;

            //Trim the value's length by 1
            if(tempValue.Length > 1)
            {
                txtValue.Text = tempValue.Substring(0, tempValue.Length - 1);
            }
            //If the text is only 1 character, back button will zero the value
            else
            {
                txtValue.Text = "0";
            }
        }
        #endregion

        #region Numeric Button Clicks
        //Pass a number or a decimal to the AddDigitToValue method
        private void btnOne_Click(object sender, EventArgs e)
        {
            AddDigitToValue("1");
        }
        private void btnTwo_Click(object sender, EventArgs e)
        {
            AddDigitToValue("2");
        }

        private void btnThree_Click(object sender, EventArgs e)
        {
            AddDigitToValue("3");
        }

        private void btnFour_Click(object sender, EventArgs e)
        {
            AddDigitToValue("4");
        }

        private void btnFive_Click(object sender, EventArgs e)
        {
            //beginNewNumber = false;
            AddDigitToValue("5");
        }

        private void btnSix_Click(object sender, EventArgs e)
        {
            AddDigitToValue("6");
        }

        private void btnSeven_Click(object sender, EventArgs e)
        {
            AddDigitToValue("7");
        }

        private void btnEight_Click(object sender, EventArgs e)
        {
            AddDigitToValue("8");
        }

        private void btnNine_Click(object sender, EventArgs e)
        {
            AddDigitToValue("9");
        }

        private void btnZero_Click(object sender, EventArgs e)
        {
            AddDigitToValue("0");
        }

        private void btnDecimal_Click(object sender, EventArgs e)
        {
            AddDigitToValue(".");
        }
        #endregion

        #region Back and Clear Buttons
        //Call method to remove a character or clear the textbox
        private void btnBack_Click(object sender, EventArgs e)
        {
            beginNewNumber = false;
            RemoveDigitFromValue();

            //set operands and value to 0 incase the user clicks = right after
            calc.operand1 = 0;
            calc.operand2 = 0;
            calc.repeatedOperationVal = 0;
            calc.currentValue = 0;
        }
        //Reset the calculator
        private void btnClear_Click(object sender, EventArgs e)
        {
            ResetCalculator();
        }
        #endregion


        #region Special operations (Sqroot, numbersign, reciprocal)
        //Change the # sign
        private void btnNumberSign_Click(object sender, EventArgs e)
        {
            if (IsDecimal(txtValue.Text))
            {
                //If number has a - in front, remove. If no -, add one
                if (txtValue.Text.StartsWith("-"))
                {
                    txtValue.Text = txtValue.Text.Substring(1);
                }
                else
                {
                    txtValue.Text = "-" + txtValue.Text;
                }
            }

        }

        //Square root
        private void btnSquareRoot_Click(object sender, EventArgs e)
        {
            try
            {
                if (IsDecimal(txtValue.Text))
                {
                    beginNewNumber = true;
                    calc.SingleOperandOperation(txtValue.Text, (short)Calculator.Operator.SquareRoot);
                    DisplayResult();
                }
                    
            }
            //Cannot square root a negative number
            catch (OverflowException oe)
            {
                txtValue.Text = "Error";
            }

        }

        //Reciprocal
        private void btnReciprocal_Click(object sender, EventArgs e)
        {
            try
            {
                if (IsDecimal(txtValue.Text))
                {
                    beginNewNumber = true;
                    calc.SingleOperandOperation(txtValue.Text, (short)Calculator.Operator.Reciprocal);
                    DisplayResult();
                }

            }
            catch (DivideByZeroException zx)
            {
                txtValue.Text = "Error";
            }
        }
        #endregion

        #region Basic Operations + - * / =
        //Add
        private void btnAdd_Click(object sender, EventArgs e)
        {
            //Valid #?
            if (IsDecimal(txtValue.Text))
            {
                //Setup for if the user wants to repeatly click =
                calc.basicOperationClicked = true;
                //prep the textbox for a new number
                beginNewNumber = true;
                //store operand and value into operand 1
                calc.StoreSingleOperand(txtValue.Text, (short)Calculator.Operator.Add);
            }

        }
        //Subtract
        private void btnSubtract_Click(object sender, EventArgs e)
        {
            if (IsDecimal(txtValue.Text))
            {
                beginNewNumber = true;
                calc.basicOperationClicked = true;
                calc.StoreSingleOperand(txtValue.Text, (short)Calculator.Operator.Subtract);
            }
        }
        //Multiply
        private void btnMultiply_Click(object sender, EventArgs e)
        {

            if (IsDecimal(txtValue.Text))
            {
                beginNewNumber = true;
                calc.basicOperationClicked = true;
                calc.StoreSingleOperand(txtValue.Text, (short)Calculator.Operator.Multiply);
            }
        }
        //Divide
        private void btnDivide_Click(object sender, EventArgs e)
        {
            try 
            {
                if (IsDecimal(txtValue.Text))
                {
                    beginNewNumber = true;
                    calc.basicOperationClicked = true;
                    calc.StoreSingleOperand(txtValue.Text, (short)Calculator.Operator.Divide);
                }
            }
            catch (DivideByZeroException zx)
            {
                txtValue.Text = "Error";
            }
}       //Equals
        private void btnEquals_Click(object sender, EventArgs e)
        {
            try
            {
                if (IsDecimal(txtValue.Text))
                {

                    beginNewNumber = true;  //set tracker to true
                    calc.DoubleOperandOperation(txtValue.Text);
                    DisplayResult();

                    //If + - / * was clicked, then toggle boolean to enable repeated operations using operand 2
                    if (calc.basicOperationClicked)
                    {
                        calc.basicOperationClicked = false;
                    }
                }
            }
            catch (DivideByZeroException zx)
            {
                txtValue.Text = "Error";
            }

        }
        #endregion


    }
}
