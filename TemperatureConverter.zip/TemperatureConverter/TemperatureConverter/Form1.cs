﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TemperatureConverter
{
    public partial class frmTemperatureConverter : Form
    {
        public frmTemperatureConverter()
        {
            InitializeComponent();
        }

        private void btnToFahrenheit_Click(object sender, EventArgs e)
        {
            //call function to convert temperature. Pass txt field and measurement system
            ConvertTempature(txtTemperature, (int)Conversion.CelsiusToFahrenheit);
        }

        private void btnToCelsius_Click(object sender, EventArgs e)
        {
            //call function to convert temperature. Pass txt field and measurement system
            ConvertTempature(txtTemperature, (int)Conversion.FahrenheitToCelsius);
        }

        //reference for conversions
        enum Conversion
        {
            CelsiusToFahrenheit = 0,
            FahrenheitToCelsius = 1
        }

        //Tempature conversion function
        private void ConvertTempature (TextBox temperatureTextBox, int measurementSystem)
        {

            Decimal temperature;

            //Validate data
            //if (IsDataValid(temperatureTextBox))
            //{
                //if number is larger than Decimal, throw exception
                try
                {
                    //Convert text to Decimal
                    temperature = Convert.ToDecimal(temperatureTextBox.Text);

                    //Convert temperature
                    switch (measurementSystem)
                    {
                        //Convert celsius to fahrenheit
                        case (int)Conversion.CelsiusToFahrenheit:
                            temperature = ((9 / (decimal)5) * temperature) + 32;
                            break;
                        //Convert fahrenheit to celsius
                        case (int)Conversion.FahrenheitToCelsius:
                            temperature = (5 / (decimal)9) * (temperature - 32);
                            break;
                    }
                    //Display result
                    temperatureTextBox.Text = temperature.ToString("f2");
                }
                //Is the number invalid?
                catch (FormatException fe)
                {
                    DisplayMessage("The number '" + temperatureTextBox.Text + "' is not a valid number. " +
                        "Please enter a valid number in the text field.", 
                        "Invalid Number", temperatureTextBox);
                }
                //If result or number is too large
                catch (OverflowException oe)
                {
                    DisplayMessage("Number is out of range. Whatchoo tryin' to do, " +
                        "calculate the temperature at the start of the Universe?", 
                        "Ye Cannae Change the Laws of Physics", temperatureTextBox);
                }
                //Catch all other unexpecteds
                catch (Exception ex)
                {
                    DisplayMessage(ex.Message +
                        "\n" + ex.StackTrace, "An Exception Has Occured", temperatureTextBox);
                }
            //}

            
        }

        //Function to display a message and set focus to the text field
        private void DisplayMessage(string message, string title, TextBox temperature)
        {
            MessageBox.Show(message, title);
            temperature.Focus();
        }

        //Close form on Exit Button click
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
