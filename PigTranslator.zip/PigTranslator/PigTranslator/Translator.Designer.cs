﻿namespace PigTranslator
{
    partial class frmTranslator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtEnglish = new System.Windows.Forms.TextBox();
            this.txtTranslation = new System.Windows.Forms.TextBox();
            this.rdoLatin = new System.Windows.Forms.RadioButton();
            this.rdoGreek = new System.Windows.Forms.RadioButton();
            this.btnTranslate = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lblTranslation = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtEnglish
            // 
            this.txtEnglish.Location = new System.Drawing.Point(12, 46);
            this.txtEnglish.Multiline = true;
            this.txtEnglish.Name = "txtEnglish";
            this.txtEnglish.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtEnglish.Size = new System.Drawing.Size(498, 169);
            this.txtEnglish.TabIndex = 0;
            // 
            // txtTranslation
            // 
            this.txtTranslation.Location = new System.Drawing.Point(12, 330);
            this.txtTranslation.Multiline = true;
            this.txtTranslation.Name = "txtTranslation";
            this.txtTranslation.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtTranslation.Size = new System.Drawing.Size(502, 271);
            this.txtTranslation.TabIndex = 1;
            // 
            // rdoLatin
            // 
            this.rdoLatin.AutoSize = true;
            this.rdoLatin.Location = new System.Drawing.Point(12, 248);
            this.rdoLatin.Name = "rdoLatin";
            this.rdoLatin.Size = new System.Drawing.Size(84, 21);
            this.rdoLatin.TabIndex = 2;
            this.rdoLatin.TabStop = true;
            this.rdoLatin.Text = "Pig Latin";
            this.rdoLatin.UseVisualStyleBackColor = true;
            this.rdoLatin.CheckedChanged += new System.EventHandler(this.rdoLatin_CheckedChanged);
            // 
            // rdoGreek
            // 
            this.rdoGreek.AutoSize = true;
            this.rdoGreek.Location = new System.Drawing.Point(114, 248);
            this.rdoGreek.Name = "rdoGreek";
            this.rdoGreek.Size = new System.Drawing.Size(92, 21);
            this.rdoGreek.TabIndex = 3;
            this.rdoGreek.TabStop = true;
            this.rdoGreek.Text = "Pig Greek";
            this.rdoGreek.UseVisualStyleBackColor = true;
            this.rdoGreek.CheckedChanged += new System.EventHandler(this.rdoGreek_CheckedChanged);
            // 
            // btnTranslate
            // 
            this.btnTranslate.Location = new System.Drawing.Point(12, 620);
            this.btnTranslate.Name = "btnTranslate";
            this.btnTranslate.Size = new System.Drawing.Size(123, 32);
            this.btnTranslate.TabIndex = 4;
            this.btnTranslate.Text = "&Translate";
            this.btnTranslate.UseVisualStyleBackColor = true;
            this.btnTranslate.Click += new System.EventHandler(this.btnTranslate_Click);
            // 
            // btnClear
            // 
            this.btnClear.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnClear.Location = new System.Drawing.Point(156, 620);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(123, 32);
            this.btnClear.TabIndex = 5;
            this.btnClear.Text = "C&lear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(391, 620);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(123, 32);
            this.btnExit.TabIndex = 6;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(155, 17);
            this.label1.TabIndex = 7;
            this.label1.Text = "Enter English text here:";
            // 
            // lblTranslation
            // 
            this.lblTranslation.AutoSize = true;
            this.lblTranslation.Location = new System.Drawing.Point(9, 310);
            this.lblTranslation.Name = "lblTranslation";
            this.lblTranslation.Size = new System.Drawing.Size(78, 17);
            this.lblTranslation.TabIndex = 8;
            this.lblTranslation.Text = "translation:";
            // 
            // frmTranslator
            // 
            this.AcceptButton = this.btnTranslate;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnClear;
            this.ClientSize = new System.Drawing.Size(533, 679);
            this.Controls.Add(this.lblTranslation);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnTranslate);
            this.Controls.Add(this.rdoGreek);
            this.Controls.Add(this.rdoLatin);
            this.Controls.Add(this.txtTranslation);
            this.Controls.Add(this.txtEnglish);
            this.Name = "frmTranslator";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Pig Latin & Greek Translator";
            this.Load += new System.EventHandler(this.frmTranslator_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtEnglish;
        private System.Windows.Forms.TextBox txtTranslation;
        private System.Windows.Forms.RadioButton rdoLatin;
        private System.Windows.Forms.RadioButton rdoGreek;
        private System.Windows.Forms.Button btnTranslate;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblTranslation;
    }
}

