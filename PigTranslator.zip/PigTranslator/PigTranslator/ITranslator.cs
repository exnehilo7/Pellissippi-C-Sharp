﻿
/* An interface named ITranslator that defines a method named Translate. 
 * This method accepts a string parameter and returns a string result.*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PigTranslator
{

    public interface ITranslator
    {
        string Translate(string result);
    }
}
