﻿/*
Translation rules:
•	Pig Latin:
    o	If a word starts with a vowel, just add way to the end of the word.
    o	If a word starts with a consonant, move the consonants before the first vowel to the end of
        the word and add ay.
    o	If a word starts with the letter Y, the Y should be treated as a consonant. If the Y appears 
        anywhere else in the word, it should be treated as a vowel.
    o	Keep the case of the original word whether it’s uppercase (TEST), title case (Test), or 
        lowercase (test).

        Mixed case will be handled based on the case of the first letter:
        XxXXxxx - change to title
        xXXxxXXxx - change to lower


    o	Keep all punctuation at the end of the translated word.
    o	Translate words with contractions. For example, can’t should be an’tcay.
    o	Don’t translate words that contain numbers or symbols. For example, 123 should be left as 123, 
        and bill@microsoft.com should be left as bill@microsoft.com.
    o	Check that the user has entered text before performing the translation.

•	Pig Greek is the same, except:
    o	If a word starts with a vowel, just add oi to the end of the word.
    o	If a word starts with a consonant, move the consonants before the first vowel to the end of the word and add omatos.

Help with regex's was from Microsoft's .NET documentation 

 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace PigTranslator
{
    static class TranslatorLogic
    {

        //strings to hold punctuation, final translated string, what case the word is, placeholder string
        private static string punctuation = "";
        private static string translatedString = "";
        private static string wordCase = "";
        private static string tempString = "";

        //Parse string into an array of words. Receive parameter indicating if translation is Latin or Greek
        static public string Translate(string str, string language)
        {
            //Clear previous translation
            translatedString = "";

            //Break string into an array
            string[] stringArray = str.Split(' ');

            //For each word: (watch out for blanks?)
            //Cycle through array of words. Use RegEx
            foreach (string s in stringArray)
            {
                //Clear punctuation holder
                punctuation = "";

                //Avoid nulls/blanks
                if (s.Length == 0)
                {
                    continue;
                }

                //Check for #s or symbols
                //what if non-letters are within the word?
                if (Regex.IsMatch(s, @"[!?.~`@#$%^&*()\-_=+\\;:"",<>/\d+][a-zA-Z]")
                    //only numbers?
                    || Regex.IsMatch(s, @"[\d+]")
                    //if there's a symbol before punctuation?
                    || Regex.IsMatch(s, @"[\#~`@$%^&*()\-_=+\\<>/""]"))
                {
                    //If any, ignore word and add to the translated string
                    translatedString = translatedString + s + " ";
                    continue;

                }

                //Check for capitalization. Record the word's case
                DetermineCase(s);


                //Check for punctuation at the end of the word
                if (Regex.IsMatch(s, @"[:;,\.\?!]$"))
                {
                    //If any, place in an array
                    punctuation = Regex.Match(s, @"[:;,\.\?!]+$") + "";
                    tempString = s.Substring(0, s.Length - punctuation.Length);
                }
                else
                {
                    tempString = s;
                }
                    

                //Check the 1st letter
                //If a vowel
                if (Regex.IsMatch(s, @"^[aeiouAEIOU]{1}"))
                {
                    //Format with ___ vowel logic
                    tempString = VowelFormatting(tempString, language);

                }   
                //If a cons
                else
                {
                    //Format with ___ cons logic
                    tempString = ConsonantFormatting(tempString, language);
                }

                //Re-capitalize
                tempString = ReCaseTheWord(tempString);

                //Re-add punctuation, if any
                tempString = tempString + punctuation;

                //Add word to a translatedString with spaces separating the words
                translatedString = translatedString + tempString + " ";
            }
        //trim space on the end
        //Return translatedString
            return translatedString.Trim();
        }


        //Function Determine Case
        static private void DetermineCase(string word)
        {
            //Is the word upper?
            if (Regex.IsMatch(word, @"^[A-Z]{2}"))
            {
                wordCase = "upper";
            }
            //title?
            else if (Regex.IsMatch(word, @"^[A-Z]{1}"))
            {
                wordCase = "title";
            }
            //else lower-case
            else
            {
                wordCase = "lower";
            }
        }

        //Word formating function vowel. Return string
        static private string VowelFormatting(string word, string language)
        {
            //If Latin, add 'way' to the end
            if (language == "latin")
            {
                word = word + "way";
            }
            //Else add 'oi' to the end
            else if(language == "greek")
            {
                word = word + "oi";
            }
            
            return word;
        }

        //Word formating function cons. Return string
        static private string ConsonantFormatting(string word, string language)
        {
            string cons;
            string tempWord;

            //Move the consonants before the 1st vowel to the end of the word
            //Get the cons. Look at everything past the 1st letter ('cause the 1st letter will be a cons)
            cons = word.Substring(0, 1) + 
                Regex.Match(word.Substring(1), @"^[^aeiouyAEIOUY]+") + "";

            //Move the cons to the end
            tempWord = word.Substring(cons.Length, word.Length - cons.Length) + cons;

            //If Latin, add 'ay' to the end
            if (language == "latin")
            {
                tempWord = tempWord + "ay";
            }
            //Else, add 'omatos' to the end
            else if (language == "greek")
            {
                tempWord = tempWord + "omatos";
            }

            return tempWord;
        }

        //Re-casing the word function
        static private string ReCaseTheWord(string word)
        {
            if (wordCase == "upper")
            {
                word = word.ToUpper();
            }
            else if (wordCase == "title")
            {
                word = word.ToLower();
                string firstLetter = word.Substring(0, 1);
                word = firstLetter.ToUpper() + word.Substring(1, word.Length - 1);
            }
            else
            {
                word = word.ToLower();
            }

            return word;
        }

    }
}
