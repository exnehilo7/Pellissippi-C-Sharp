﻿
/*
DATE: 20-NOV-2020
Programmer: Dan Hopp
Description: 
•	The user enters text in the first multi-line text box, selects whether to translate the text into Pig Latin
    or Pig Greek, and clicks the Translate button or presses the Enter key.
•	The application translates the text to Pig Latin or Pig Greek and displays it in the second multi-line 
    text box.
•	When the user selects the Pig Latin or Pig Greek option, the label above the second text box changes
    accordingly, and the second text box is cleared.

•	There is an interface named ITranslator that defines a method named Translate. This method accepts a 
    string parameter and returns a string result.
•	There are two classes named PigLatinTranslator and PigGreekTranslator that implement the ITranslator 
    interface.
    
    The two classes use a translator static class to handle the parsing and word translation, TranslatorLogic

 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PigTranslator
{
    public partial class frmTranslator : Form
    {
        public frmTranslator()
        {
            InitializeComponent();
        }

        //exit button
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //Clear button
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtEnglish.Text = "";
            txtTranslation.Text = "";

        }

        //Update translate label based on option selection. Clear out translation
        private void rdoLatin_CheckedChanged(object sender, EventArgs e)
        {
            lblTranslation.Text = "Pig Latin Translation:";
            txtTranslation.Text = "";
        }
        private void rdoGreek_CheckedChanged(object sender, EventArgs e)
        {
            lblTranslation.Text = "Pig Greek Translation:";
            txtTranslation.Text = "";
        }

        //Form Load
        private void frmTranslator_Load(object sender, EventArgs e)
        {
            rdoLatin.Checked = true;
        }

        //Translate button
        private void btnTranslate_Click(object sender, EventArgs e)
        {
            //Is there something to translate?
            if (txtEnglish.Text.Trim().Length > 0)
            {
                //Latin translation
                if (rdoLatin.Checked)
                {
                    PigLatinTranslator oinkWay = new PigLatinTranslator();
                    Console.WriteLine("Begin Latin translation.");
                    txtTranslation.Text = oinkWay.Translate(txtEnglish.Text);
                }
                //Greek translation
                else if(rdoGreek.Checked)
                {
                    PigGreekTranslator oinkOi = new PigGreekTranslator();
                    Console.WriteLine("Begin Greek translation.");
                    txtTranslation.Text = oinkOi.Translate(txtEnglish.Text);
                }
            }
        }
    }
}
