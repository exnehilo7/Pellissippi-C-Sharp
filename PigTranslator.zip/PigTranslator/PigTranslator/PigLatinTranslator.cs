﻿//Class for pig latin translation. Calls universal-translating function

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace PigTranslator
{
    class PigLatinTranslator : ITranslator
    {
        public string Translate(string str)
        {
            return TranslatorLogic.Translate(str, "latin"); 
        }
    }
}
