﻿/* Date: 06-OCT-2020
 * Programmer: Dan Hopp
 * Description: Main form of the Student Scores app. The application allows the user to add students to a 
 * list, change the scores for a student in the list, and delete a student or their scores from the list.
 * Each score is a valid integer from 0 to 100. When adding a new student their name cannot be blank,
 * but they can be added without any scores.
 * 
 * Students will be stored in one object per. A Student object contains their name(string) and a list of
 * their scores(int).
 * 
 * The form loads with three example students. Selecting an item from the list will display the total, 
 * count, and average score for a student. If the list box is empty, the aggregate labels are cleared.

*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace StudentScores
{
    //Main form
    public partial class frmStudentScores : Form
    {

        //A list to hold all the Student objects
        private List<Student> ListOfStudents;

        public frmStudentScores()
        {
            InitializeComponent();
            //Create a new ListOfStudents
            ListOfStudents = new List<Student>();
        }

        //Form load
        private void frmStudentScores_Load(object sender, EventArgs e)
        {

            //Generate three sample students
            //01
            Student sampleStudent_01 = new Student();
            sampleStudent_01.StudentName = "Diana Prince";
            sampleStudent_01.StudentScores.Add(100);
            sampleStudent_01.StudentScores.Add(100);
            sampleStudent_01.StudentScores.Add(100);
            sampleStudent_01.StudentScores.Add(100);

            //02
            Student sampleStudent_02 = new Student();
            sampleStudent_02.StudentName = "Dan Hopp";
            sampleStudent_02.StudentScores.Add(94);
            sampleStudent_02.StudentScores.Add(96);
            sampleStudent_02.StudentScores.Add(98);

            //03
            Student sampleStudent_03 = new Student();
            sampleStudent_03.StudentName = "Sniper Wolf";
            sampleStudent_03.StudentScores.Add(100);
            sampleStudent_03.StudentScores.Add(100);
            sampleStudent_03.StudentScores.Add(98);

            //Add sample students into the Student object array
            ListOfStudents.Add(sampleStudent_01);
            ListOfStudents.Add(sampleStudent_02);
            ListOfStudents.Add(sampleStudent_03);


            //Populate the listbox
            PopulateStudentsListbox();

        }

        //Function to calculate and populate score aggregates of selected student
        private void CalculateScoreAggregates()
        {

            int scoreTotal = 0;
            int scoreAverage = 0;
            int scoreCount = 0;

            //Get selected item
            Student selectedItem = (Student)lbxStudents.SelectedItem;

            //Loop through the scores in a Student object and get the values for aggregation
            foreach (int score in selectedItem.StudentScores)
            {
                scoreTotal = scoreTotal + score;
                scoreCount = scoreCount + 1;
            }

            //Get average
            //If student has no scores, skip
            if(scoreCount > 0)
            {
                scoreAverage = scoreTotal / scoreCount;
            }

            //Show Score total
            lblScoreTotal.Text = scoreTotal.ToString();

            //Show Score count
            lblScoreCount.Text = scoreCount.ToString();

            //Show Score average
            lblAverageSore.Text = scoreAverage.ToString();

        }

        //Function to populate the listbox with the students and scores array
        private void PopulateStudentsListbox()
        {

            lbxStudents.Items.Clear();

            foreach (var item in ListOfStudents)
            {
                lbxStudents.Items.Add(item);
            }
        }


        //Close form on Exit button click
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //Update the score aggregates when a different item is selected on the Scores listbox
        private void lbxStudents_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lbxStudents.SelectedIndex > -1)
            {
                CalculateScoreAggregates();
            }
            //if the list is blank, clear the aggregate values from the form
            else
            {
                ClearAggregates();
            }
                
        }

        //Function to clear the aggregate lables
        private void ClearAggregates()
        {
                lblScoreTotal.Text = "";
                lblScoreCount.Text = "";
                lblAverageSore.Text = "";
        }

        //Delete the highlighted item from the student listbox
        private void btnDeleteStudent_Click(object sender, EventArgs e)
        {
            //Is an item selected?
            if (lbxStudents.SelectedIndex > -1)
            {
                //Verify if the user wants to delete a student record
                DialogResult response = MessageBox.Show("Warning! The student's record will be permanently " +
                    "deleted.\n\nContinue?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                if (response == DialogResult.Yes)
                {
                    //Get selected item
                    Student selectedItem = (Student)lbxStudents.SelectedItem;

                    //Remove student from the list
                    ListOfStudents.Remove(selectedItem);

                    //Reset the aggregate values
                    ClearAggregates();

                    //Refresh the student listbox
                    PopulateStudentsListbox();
                }

            }
            //if nothing is selected, display message
            else
            {
                MessageBox.Show("There is no student selected!", "No Student Selected", 
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }


        }

        //Open the Add Student form
        private void btnAddNewStudent_Click(object sender, EventArgs e)
        {
            //Open add form as dialog box. Get the form's DialogResult
            Form addNewStudentForm = new frmAddNewStudent();
            DialogResult result = addNewStudentForm.ShowDialog();


            //If result == OK, add new student and scores to the student and scores list (if any)
            if (result == DialogResult.OK)
            {
                ListOfStudents.Add((Student)addNewStudentForm.Tag);

                //Refresh the listbox
                PopulateStudentsListbox();

                //Clear the aggregates
                ClearAggregates();

            }
        }

        //Open the Update Student form
        private void btnUpdateStudent_Click(object sender, EventArgs e)
        {
            //Is an item selected?
            if (lbxStudents.SelectedIndex > -1)
            {
                //Get the selected student
                Student selectedStudent = (Student)lbxStudents.SelectedItem;

                //Open add form as dialog box
                Form updateStudentForm = new frmUpdateStudentScores();

                //Pass the selected student to the new form's tag
                updateStudentForm.Tag = selectedStudent;

                //Get the form's DialogResult
                DialogResult result = updateStudentForm.ShowDialog();

                //If the result is OK, refresh the listbox and aggregates
                if (result == DialogResult.OK)
                {
                    PopulateStudentsListbox();
                    ClearAggregates();
                }
            }

        }


        #region Public data validation functions
        //Public function to validate a score
        public static bool IsScoreValid(string score)
        {
            //Is it not blank, an integer, and within range?
            return (IsScoreNotBlank(score) && IsScoreAnInteger(score) && IsScoreInRange(score));
        }

        //Function to validate the score range, 0 - 100 inclusive
        private static bool IsScoreInRange(string score)
        {
            int scoreInteger = 0;
            scoreInteger = Int32.Parse(score);
            if (scoreInteger >= 0 && scoreInteger <= 100)
            {
                return true;
            }

            MessageBox.Show("Invalid range!\n\nThe score has to be from 0 to 100.",
                "Score Out of Bounds",
                MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            return false;
        }

        //Function to validate if score is an integer
        private static bool IsScoreAnInteger(string score)
        {
            int scoreInteger = 0;
            if (Int32.TryParse(score, out scoreInteger))
            {
                return true;
            }

            MessageBox.Show("\"" + score + "\" is not an integer!", "Invalid Integer",
                MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            return false;
        }

        //Function to validate if score is not blank
        private static bool IsScoreNotBlank(string score)
        {

            if (score.Length > 0)
            {
                return true;
            }

            MessageBox.Show("The score field is blank!", "No Score",
                MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            return false;
        }

    }
    #endregion


}
