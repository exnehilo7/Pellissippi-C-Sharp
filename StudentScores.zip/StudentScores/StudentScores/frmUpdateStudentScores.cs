﻿/* Date: 06-OCT-2020
 * Programmer: Dan Hopp
 * Description: The Update Student form. Modal. The form loads with the name of the selected student on the
 * main form, and a list of their scores, if any. When the user is finished with their changes, the list's
 * values will be overwritten on the student score's list
 * 

*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentScores
{
    public partial class frmUpdateStudentScores : Form
    {
        //Object variable to hold the Student object from the main form
        private Student TempStudentObject;
        private List<int> TempListBox;

        public frmUpdateStudentScores()
        {
            InitializeComponent();

        }

        //Form load
        private void frmUpdateStudentScores_Load(object sender, EventArgs e)
        {
            //Put tag in object variable
            TempStudentObject = (Student)Tag;
            TempListBox = new List<int>();


            //Populate the temp list
            foreach (int item in TempStudentObject.StudentScores)
            {
                TempListBox.Add(item);
            }

            //Display the selected student's scores on the form, if any
            lblName.Text = TempStudentObject.StudentName;

            PopulateScoresListbox();

        }

        //Remove the selected score 
        private void btnRemove_Click(object sender, EventArgs e)
        {
            //Is an item selected?
            if (lbxScores.SelectedIndex > -1)
            {
                //Remove the selected score from the object's score list, using the index values
                TempListBox.RemoveAt(lbxScores.SelectedIndex);

                //Refresh the listbox
                PopulateScoresListbox();
            }
        }

        //Fill the score list box with any scores, using the temp List
        private void PopulateScoresListbox()
        {

            lbxScores.Items.Clear();

            foreach (int item in TempListBox)
            {
                lbxScores.Items.Add(item.ToString());
            }
        }

        //Close the form. Pass OK dialog result back to main form
        private void btnOK_Click(object sender, EventArgs e)
        {
            //Overrwrite the student object's score list with the data from the temp list
            TempStudentObject.StudentScores.Clear();

            foreach (int item in TempListBox)
            {
                TempStudentObject.StudentScores.Add(item);
            }

            //Set this form's dialog result
            this.DialogResult = DialogResult.OK;
        }

        //Remove all of a student's scores
        private void btnClearScores_Click(object sender, EventArgs e)
        {
            //If there are scores to remove, continue
            if (TempListBox.Count > 0)
            {
                //Verify with the user if they want to remove all the scores
                DialogResult response = MessageBox.Show("Warning! All student scores will be cleared."
                    + "\n\nContinue?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                if (response == DialogResult.Yes)
                {
                    TempListBox.Clear();

                    //Refresh the listbox
                    PopulateScoresListbox();
                }
            }
        }

        //Open a form to add a score to the student's score list
        private void btnAdd_Click(object sender, EventArgs e)
        {

            //Open add form as dialog box
            Form addScoreForm = new frmScoreAdd();

            //Pass the student object to the new form's tag
            addScoreForm.Tag = TempListBox;

            //Get the form's DialogResult
            DialogResult result = addScoreForm.ShowDialog();

            //If the result is OK, refresh the listbox
            if (result == DialogResult.OK)
            {
                PopulateScoresListbox();
            }
        }

        //Update button
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            //Is an item selected?
            if (lbxScores.SelectedIndex > -1)
            {
                //Get the selected score
                int selectedScore = Int32.Parse(lbxScores.Text);

                //Open add form as dialog box
                Form updateScoreForm = new frmScoreUpdate();

                //Pass the selected score to the new form's tag
                updateScoreForm.Tag = selectedScore;

                //Get the form's DialogResult
                DialogResult result = updateScoreForm.ShowDialog();

                //If the result is OK, add the score to the student object and refresh the listbox
                if (result == DialogResult.OK)
                {
                    //Get the selected item's index
                    int index = lbxScores.SelectedIndex;

                    //Remove the item
                    TempListBox.RemoveAt(index);

                    //Insert the new score at the index
                    TempListBox.Insert(index, (int)updateScoreForm.Tag);

                    //Refresh the listbox
                    PopulateScoresListbox();
                }
            }
        }
    }
}
