﻿/* Date: 06-OCT-2020
 * Programmer: Dan Hopp
 * Description: The Add New Student form. Modal. When adding a new student their name cannot be blank,
 * but they can be added without any scores. New scores are added to a string that is displayed
 * in a label field. When the user is finished the scores will be split and added into the student
 * object.

*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentScores
{
    public partial class frmAddNewStudent : Form
    {
        public frmAddNewStudent()
        {
            InitializeComponent();
        }


        //Add the score to the label.
        private void btnAddScore_Click(object sender, EventArgs e)
        {

            //If entry is non-integer and within range (0 - 100, inclusive) continue
            if (frmStudentScores.IsScoreValid(txtScore.Text.Trim()))
            {
                lblStudentScores.Text = lblStudentScores.Text + txtScore.Text + " ";

                //Clear txtScore
                txtScore.Text = "";

                //Set cursor to score field
                txtScore.Focus();
            }
        }

        //OK Click. Add the student name and their scores (if any) to a Student object, close the form,
        //and pass the object to main form to add to its list
        private void btnOK_Click(object sender, EventArgs e)
        {
            DialogResult result = DialogResult.Yes;

            //If student field is not blank, continue
            if (txtName.Text.Trim() != "")
            {
                //Is there a score pending to be added to the list?
                if (txtScore.Text.Trim() != "")
                {
                    result = MessageBox.Show("A score has not been added to the list!"
                    + "\n\nContinue?", "Score Pending",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                }

                if (result == DialogResult.Yes)
                {
                    //Create object
                    Student newStudent = new Student();

                    //Add student name
                    newStudent.StudentName = txtName.Text.Trim();

                    //Set result for the main form to read
                    this.DialogResult = DialogResult.OK;

                    //Create the Student object and add it to this form's tag
                    //Are there any scores?
                    if (lblStudentScores.Text != "")
                    {
                        //Split the scores (if any) into an array, then add the items to 
                        //the Student's score list
                        string[] splitString = lblStudentScores.Text.Split(' ');

                        foreach (string item in splitString)
                        {
                            //Ignore the blanks
                            if (item.Length > 0)
                            {
                                newStudent.StudentScores.Add(Int32.Parse(item));
                            }
                        }
                    }

                    //Assign Student object to this form's tag
                    this.Tag = newStudent;
                }
            }
            else
            {
                MessageBox.Show("There is no student to add!", "Field is Blank",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        //Clear the score label and score field
        private void btnClearScores_Click(object sender, EventArgs e)
        {
            lblStudentScores.Text = "";
            txtScore.Text = "";
        }
    }
}
