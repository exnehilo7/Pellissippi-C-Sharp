﻿/* Date: 06-OCT-2020
 * Programmer: Dan Hopp
 * Description: The Add Score form. Modal. The score is added to the selected student's score list

*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentScores
{
    public partial class frmScoreAdd : Form
    {
        //List variable to hold the Student's scores from the Update Scores form
        private List<int> TempScoreList;

        public frmScoreAdd()
        {
            InitializeComponent();
        }

        //Form load
        private void frmScoreAdd_Load(object sender, EventArgs e)
        {
            //Put tag in list variable
            TempScoreList = (List<int>)Tag;
        }

        //Cancel button
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //Add the score to the score list and close the form
        private void btnAdd_Click(object sender, EventArgs e)
        {
            //Is score valid?
            if (frmStudentScores.IsScoreValid(txtScore.Text.Trim()))
            {
                //Set result for the Update Student Scores form to read
                this.DialogResult = DialogResult.OK;

                //Add the score to the list
                TempScoreList.Add(Int32.Parse(txtScore.Text.Trim()));

            }
            //Set cursor in text field if invalid
            else
            {
                txtScore.Focus();
            }
        }
    }
}
