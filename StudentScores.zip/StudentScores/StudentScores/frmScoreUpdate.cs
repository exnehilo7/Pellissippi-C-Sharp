﻿/* Date: 06-OCT-2020
 * Programmer: Dan Hopp
 * Description: The Update Score form. Modal. The selected student's score is updated in thier score list

*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentScores
{
    public partial class frmScoreUpdate : Form
    {
        //Int variable to hold the Student score from the Update Scores form
        private int tempScore;

        public frmScoreUpdate()
        {
            InitializeComponent();
        }

        //Form load
        private void frmScoreUpdate_Load(object sender, EventArgs e)
        {
            //Load the selected score into the textfield
            tempScore = (int)this.Tag;
            txtScore.Text = tempScore.ToString();

        }

        //Cancel button
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //Update button
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            //Is score valid?
            if (frmStudentScores.IsScoreValid(txtScore.Text.Trim()))
            {
                //Set result for the Update Student Scores form to read
                this.DialogResult = DialogResult.OK;

                //Pass the integer back to the Update Student Score form
                this.Tag = Int32.Parse(txtScore.Text.Trim());

            }
            //Set cursor in text field if invalid
            else
            {
                txtScore.Focus();
            }
        }
    }
}
