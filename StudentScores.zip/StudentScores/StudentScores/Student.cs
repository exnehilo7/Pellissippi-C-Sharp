﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentScores
{
    public class Student
    {
        //The Student class will contain a string and an optional list of integer scores.
        //An individual score's range is 0 - 100

        //Student Name
        public string StudentName { get; set; }

        //Student score(s)
        public List<int> StudentScores { get; set; }

        //Instantiate the List<> for when a new student is created
        public Student()
        {
            StudentScores = new List<int>();
        }

        //Specify what ToString() is to be for this class
        public override string ToString()
        {
            //Create the string that will be displayed in the Student listbox on the main form
            //name|#|#|#...
            string studentString = "";

            studentString = studentString + StudentName;

            foreach(int item in StudentScores)
            {
                studentString = studentString + "|" + item.ToString();
            }

            return studentString;
        }

    }
}
