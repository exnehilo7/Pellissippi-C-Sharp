﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Robot
{
    class Robot
    {

        #region Variables
        //Current position
        public int RobotPosX { get; set; }
        public int RobotPosY { get; set; }
        public int LabelPosX { get; set; }
        public int LabelPosY { get; set; }

        //Current direction
        public int currentDirection { get; set; }

        //Robot max range (in any direction)
        int maxRange = 100;

        //Enumeration for wingding arrows
        public enum Arrow : int
        {
            N = 233,
            S = 234,
            E = 232,
            W = 231
        }
        #endregion

        #region Constructors, Strings, and Events
        //Constructor
        public Robot(int positionX, int positionY, int LabelPosX, int LabelPosY, int dir)
        {
            this.RobotPosX = positionX;
            this.RobotPosY = positionY;
            this.LabelPosX = LabelPosX;
            this.LabelPosY = LabelPosY;
            this.currentDirection = dir;

            //wire the event
            OOBevent += new OutOfBoundsDelegate(DisplayMessage);
        }

        //String for the current position label. Reverse Y's number sign for standard math grid coords
        public string robotsCurrentPos()
        {
            return "{X=" + RobotPosX + ", Y=" + RobotPosY * -1 + "}";
        }

        //Delegate and Event for out of bounds
        public delegate void OutOfBoundsDelegate();
        public event OutOfBoundsDelegate OOBevent;

        //OOB message
        private void DisplayMessage()
        {
            MessageBox.Show("The robot cannot move more than " + maxRange + " spaces in any direction.",
                    "Maximum Range");
        }

        #endregion
        
        #region Robot Movement Logic
        //If movement will be within range, move the robot (adjust it's position)
        //Move the robot (adjust it's position)
        public void updatePositions(int moveDistance)
        {
            //Cannot go past max range
            if (isMovementValid(moveDistance))
            {
                if (this.currentDirection == (int)Arrow.N)
                {
                    this.RobotPosY -= moveDistance;
                }
                if (this.currentDirection == (int)Arrow.S)
                {
                    this.RobotPosY += moveDistance;
                }
                if (this.currentDirection == (int)Arrow.E)
                {
                    this.RobotPosX += moveDistance;
                }
                if (this.currentDirection == (int)Arrow.W)
                {
                    this.RobotPosX -= moveDistance;
                }

            }
            else
            {
                //Raise outOfBounds event
                OOBevent();
            }

        }
        
        //Will the movement go out of bounds?
        private bool isMovementValid(int moveDistance)
        {
            //N
            if (this.currentDirection == (int)Arrow.N)
            {
                if (Math.Abs(this.RobotPosY - moveDistance) > maxRange)
                {
                    return false;
                }
            }
            //S
            if (this.currentDirection == (int)Arrow.S)
            {
                if (Math.Abs(this.RobotPosY + moveDistance) > maxRange)
                {
                    return false;
                }
            }
            //E
            if (this.currentDirection == (int)Arrow.E)
            {
                if (Math.Abs(this.RobotPosX + moveDistance) > maxRange)
                {
                    return false;
                }
            }
            //W
            if (this.currentDirection == (int)Arrow.W)
            {
                if (Math.Abs(this.RobotPosX - moveDistance) > maxRange)
                {
                    return false;
                }
            }
            return true;
        }
        #endregion

    }
}
