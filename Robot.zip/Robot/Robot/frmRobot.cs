﻿/* Date: 04-NOV-2020
 * Programmer: Dan Hopp
 * Description: 
•	There is a class named Robot that has a method that causes the robot to move, a public field that contains
the current direction, and a property that returns the robot’s current position as a Point structure. 
When the robot is instantiated, the position is set to 0, 0 (the center) and the direction is set to North.

•	The range of the robot is limited to 100 units in any direction. If the user attempts to move the robot 
beyond this range, the Robot class will raise an event. The application responds to this event by displaying 
an appropriate message. 

•	To determine the direction the robot will move, the user clicks the N (North), S (South), E (East), 
or W (West) button.

•	The robot is displayed as an arrow that points in the currently selected direction. The robot 
(the label with an arrow)'s position on the form will be the robot's position offset by the center of
its movement field.

•	The user can move the robot 1 or 10 units in the selected direction by clicking the Go 1 or Go 10 button.

•	The robot’s current X, Y position is displayed in a label at the top of the form.

 */


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Robot
{
    public partial class frmRobot : Form
    {

        //Initialize robot. Start at 0,0 (center of the field for the form is 135, 175) and facing north
        Robot beepBoop = new Robot(0, 0, 135, 175, (int)Robot.Arrow.N);


        public frmRobot()
        {
            InitializeComponent();
        }

        //Form load
        private void frmRobot_Load(object sender, EventArgs e)
        {

            //Display the robot & coords
            displayRobotAndCoords();

        }


        #region Robot and Coordinates label Display
        //Function to show the robot
        public void displayRobotAndCoords()
        {
            lblRobot.Location = new Point(beepBoop.LabelPosX + beepBoop.RobotPosX, 
                beepBoop.LabelPosY + beepBoop.RobotPosY);
            lblRobot.Text = "" + (char)(beepBoop.currentDirection);

            //Update the coordinate label
            updateCoordinateLabel();
        }
        //Function to update the coordinate label
        private void updateCoordinateLabel()
        {
            lblCoordinates.Text = beepBoop.robotsCurrentPos();
        }
        #endregion

        #region Direction Buttons
        private void btnSouth_Click(object sender, EventArgs e)
        {
            beepBoop.currentDirection = (int)Robot.Arrow.S;
            displayRobotAndCoords();
        }

        private void btnNorth_Click(object sender, EventArgs e)
        {
            beepBoop.currentDirection = (int)Robot.Arrow.N;
            displayRobotAndCoords();
        }

        private void btnWest_Click(object sender, EventArgs e)
        {
            beepBoop.currentDirection = (int)Robot.Arrow.W;
            displayRobotAndCoords();
        }

        private void btnEast_Click(object sender, EventArgs e)
        {
            beepBoop.currentDirection = (int)Robot.Arrow.E;
            displayRobotAndCoords();
        }
        #endregion

        #region Movement Buttons
        private void btnGo01_Click(object sender, EventArgs e)
        {
            beepBoop.updatePositions(1);
            displayRobotAndCoords();
        }

        private void btnGo10_Click(object sender, EventArgs e)
        {
            beepBoop.updatePositions(10);
            displayRobotAndCoords();
        }
        #endregion

        //Exit button
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
